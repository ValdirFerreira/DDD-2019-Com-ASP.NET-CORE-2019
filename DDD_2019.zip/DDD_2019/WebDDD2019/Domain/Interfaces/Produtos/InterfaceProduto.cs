﻿using Domain.Entidades;
using Domain.Interfaces.Genericos;
using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Interfaces.Produtos
{
    public interface InterfaceProduto : InterfaceGenerica<Produto>
    {

    }
}
