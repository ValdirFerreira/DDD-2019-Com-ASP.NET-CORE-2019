﻿using Domain.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Applications.Interface
{
    public interface InterfaceAppProduto : InterfaceGenericaApp<Produto>
    {

    }
}
